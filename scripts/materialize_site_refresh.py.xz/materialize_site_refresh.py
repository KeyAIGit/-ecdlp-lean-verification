#!/usr/bin/env python3
"""One-shot materializer for the verified-results and site-clarity update.

The bootstrap workflow runs this on the feature branch, writes the ordinary
source/generated files, validates them, and removes the bootstrap artifacts.
"""
from __future__ import annotations

import base64
import lzma
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Filled below by the local staging script.
PAYLOADS: dict[str, str] = {
    'scripts/build_dashboard.py': '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~p!r0bKwQh(bq-BQwKy4>SE$m+hy=@aif<Hp(x6uSQQU^?`u_P0C>$LnqeVo|}&vM#NuZGSt(I^|lF)MI<X7`LubC&jC~s?6vPo^r-63oZCTlqeb{|BeAw3Y7Jy7i0Y;+n5-5{D$)B>5A3y;?pMc&8I1$(@4917c>mvnXzwr04WqLw17dN1;BJR|<3<!6kB)a=rA_-#Zdcn0t%{FTB)XoP%Sa!`y`xKBURrlfm!$wh#zw+g6{yjF!M!G8xtwa@CQ)uQxRAq;>MMnrw?XR`x!9men?Xw8>HSRQtLq2sSV+Keg=={;lY#vV<tDIJFj%@eFrVi)<nmI300000?1W42BOwt600Er>r~?21lMVEevBYQl0ssI200dcD',
    'scripts/build_results_portal.py': '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;6%q2e_a3(h(bq-BQwKy4>SE$m+hy=@aif<Hp(x6uSQJad0^{&ygD}Rr~m04T*$--)`sHQmb&EU{dE<n0Ww2#{nw#D!oCuM%)>!an-jqbOp4JLU5VOaJt;D%ym;eV$V{XY51_v1A-zi@cl!JjCq#~LoF-%vsg2bDcqM4_>WFy>O~@0Db;!xu0a)<jsk-gGcqRNuUNCg)#3dS4f?#O<ea%4yRcb6&6xZ*J|Lbr)adO>1->qN83M*PG_@P^5;9WX1v2wb-)x81Qo)JtE?DH9^;|9VI0xh6_flar>HWo+qqlPm7^XsSRIK=S~bDOS&Zdz##s&MN5ta~o1iHm9`(Po_#Q>UDSPdW?qO`ssGJ=!4IrWOdiVF?v^#VZtJ6}lD<gabo=O#Em3+(|+4z$QwmR_IfiUJxJDg!25cHmS?aw4%#TYO3j(vG3v4Y-m7AOHCN`;%DrDa9``2S}^R18*LPS_!xd$9z2MD^C30;AicR*B&%BhX{B84*oCI1r`F&)_{`D>ow-T;c#M~F%FncPq*lnMWGT$Ni+TuDTXkp5+{Fgn(2e`E0y%pH2NGAK_rz8ZsP*y2<Imb+xQ2-4#N<49#;iTG3HTZ*7rUcp7t@ta-Hv@nE{>WVX5fu0k7}?dN}5JAA4@skTE7XD9~kaj#W34`d)S`e%%NgI`)owCY(U#LKMT$NRg0|F%y`oS?%#nkHqkP+hChGuT4+oR@DQ-mxlu()2wry<0hCC)5R3+k^5JkQ2=*zo365;EBnX=Z#$s}Rxx5|90WE3;P+&&H!5xY8*?DgV4zr}AL&pqHkDv>uJ_Fu8f0cpPlYNx<T~}9Uif}#i-%mZ-nTX1qsVf-4pdpf-ICnu^TrHj^Z^Y48a9uxAo|~obr-#YU4jN<zjXAV{_$gd87Mt~&w8>~fiuvG~dUky5ZC!5MX+B1opnB-6=WxcE$pX`3nI9MMJ=OF?9K6=JB>c>Z6?J`p4AH=DH3?{asZ~W$Oa(<Df)VNgQfk30eso?SEu5<w1v}zk0eRp{rB^}Fg)lpWUZ7^ZO)r5`d_s1UWY1c~d|xw!(tfcdKk*0y?v@5?OCde<Q<rZihimYIehf7yrH!hWLFf5E(<t8oNMOmRU(I%ixaaQ6)_h*9gd8iAKnMjKPl6HBpu0OoY$9sV9-w#B$zl!2!DN4+$P~Upr_XJud6ZKB29#2L`l_Zi)0sG01Bx6z_;zU=bt95~C87o{7f=dp(j-Fz8O#LWvK|2LV0NzUTiJ5EBr6Z~=bw}3Bfvb1HWS25Ly8}dK(}VPeu)sw#OcQbz5grIfVLoiLAzF~hMW_YVfOlNAV^)Ta+#eAPp!vo`#K_N9f7uv0F6R4BRK$g!z5S#&$+AfMi`)1ko)VgZPFM1TC;SO)FhU%;LbYq8s{})KF1>Twe0|@)o#)U$#1!sqP;<?32{ZSm9RyeK5kdWU%or@A|ty=1Rex;8!swC2pA}O@kPKNjBBO~9r!~t^~(FAWp}eECOlNcfYhSjUn1}6lhU4{hBEX@`C_Q;G8r?0lKYxKAW9fMw5mS_l*|>J2630&@sIQ#8$tMz^X@EUy#xK0gqJERj2`Xtn9U%Z-eZ><Ohw+eGDU_DJ%#_bv9n9C)=A|#EjP8ntB!77rd1m%Xm)+L;dnjHC#ryVTg+_w;KSzl*|*9tT0kvjjebplvOJGnj8LVp>%zRo=DaGz__)Ziw^cXPo`$v$(IM!3F&yaS)irUY@h1;u{uqSi#n}i3!zzbO1vGZJ1sH(=eYo`o06U4)?-v~q)ASqVO@cEo3;W|RI5AH!*te^F#4KgW{!F;J7uMU~=EqGR?k;=yKnYMhj`}GqY&rANtK5leZCcC-pk~0t>G1^%FkTI~^GKmW4X*9qEt)^Sb}wM#2eMu&-2&pWum*PVb)I#=-|uLI+PMD>t1;18RSO!WXIi#Y^MNc5WSE%^=1;Xk&C@IJh&bL06FAERV8EOf<50pJ%2eawo)K0^{((m9@EP)r_y}JFT+o*Uz$!VPgpXW^wEk20G_N8y%p7}R5I*OuVqX{JS>J<!AE`)?NyG2%mvs%C8eyc1zv1lS;%b3X{UphuV{S@~5c<p5aL|n<l2GX1owOeu^!Eb#v;IvH%}dw2E4)(HdW%ht!>U0HC#0UjEV+Mg$~^!fA!lS`O+Dc*K8?Y12F);W6?jabh5`+#nABJSju#SZalTKEts+~mu~_3nN|R0g7IR~}6ms|6xa_Y7D)!6MmAQ%A^Kbk1=kO!Opz;5`C%?^wJt#009BP+yJrI%+w{bQVqx9OuQk}4cW#ip|xM*YUewjHveKPo&2VEr44PIKy!9AUhQ_>IloW`3_IP3QZ?Hd7T9w0uO0v{d0Va?5FZk$yx-AsmQN8wd+<_FLP;o=^5{YDQcyh+kS!yta8(=^jk6eMEu%Rkx})DHE$90ihowXWI=0*-$byUl;=ums!;SGhi9kbOdEr2#tBoe&4S>F6?t=z^H!v$#pX`|IJH>?QtkRiY;;X;F-8N|2*!#{-M&lCD0$eDiM`gvALB!Kg8vSybx1ZV4CdYh1S6q0nyhMQmZR$(9CvWLIzR^eZKp?N$^_CP_E`De2cf+zS*Y#Yt;v6GKP4F^ZsYwdX9FoT|+9d}U+SWD_JaJbF!}RFhorgTTh;PKzDOi`ZRX&lzwLac?@aS})F>--ulSONGPg&n@&fRSN)G7FKS-2F-=(KrWk+kBksM5?ZcQ`^<spukaR;&BoA4>ifXXM*NVM94)8%+--xSS|LsqE$@(hG4!oah}JsBqSYl_VzC}E4%oMrYxt~-2XLx45ruhx;v|&Jn@rckYK49Cj)de;mk5hfw09iuLh_sU%i80O!Iq2;VfMXxzXIy7q=ShE*hMGzNoTPG)rM<xIY;B;YUUaJgf-_Aj`N<zy}<;)gZ@ua?1ba-A@gY<z~Ke&O3YIjRN$sG@1kv*^@~H)hl(IqVu#@Ih+;v(uW<Pd5+t}y7u6?`Ya!7V(XA_gL^@oreR>i0%}0{uEhNJgEBk3kb`z5pQ3N!MB6~snOATq|plmySXYR%SpTxsBB)nBXt$;65W0jitCQ27_<}XX7s_R;yyL$!EW5_1p{J@soG!bX^8Bdc=cWilbU=JW;7&u27-|2A;pMQz@zKP*uCMveU5p`)YEf=)$V$k9#93QV<q3GEMQ~%2U-x4~(vP<|(z6uH-?TIRIJbL3nP0=Y{y$lSK4Y#R5J+~jOssqLp=%G;|Wcc0_bt+0P0I_5a>gfE|CRE3crX?P2@}`c$NA^}kAm?u7NNQ}d@vTXMF6(1FBvB)2JAc4}!*2>ZEq`ytF`1h$(b6RT4b;~~W?fIoKRPfk(9*1l`HZBDgq`1SzjvLG>D-QKs-=$k|4FN27BC91=mt`oN_yG{G?KrN>MK*?jp_5_!JcExEvA7Aj5|(PW;46YX`y|^)TK=nLGi0*@sndz&U$7mcYa1V^vL(!EfAnGAcW3+{cLY7Jr+ay^0Ox*VKhQXwz1*_ANRLHy=c7ed({|LfRa1Bx5*gIT+|6OFX+}KA29_t7*Gh+t#+>G)@flT@UG>QGd+N@6+k^)z*zrH?Pzr(!>hrLWDP7>IMI;D5bV*k&2du?oPiiqIY$$B$OKvzDdqsTpUV9!EjKm{Be)AvE12s@uk5;sJH$VjbbY93I_t}NbOON4MGJ?6-K;nYd5gRm^C#$x_1z-TH~@nA;f>%!ju|$WI?AjZQQjty^kZp(VaErZ)!utIE$K=(=F)svN3ZW@#$8++>ekcC+FH{_Z)bT>4u!N6+^~-^pJwjzTK|84C6b?hU@L3j><M)DoqEn^U4C!&X!&TvC15c4apy}S7s1$fTg26=6D9CL{-P4v>q2u|&&PU@o*^>NLOW-s*Hl(zEpP3<QheN29nJ;TePJ=8E7JytHfMieU)J-Kye^!ouGq@eo>yAFg(s0x{jJy}I~}dDe7-DdhUw&i5tW@O0Rn+u14lK(3knsc3S2FGb3QevkMah|6W0-r9IjZbzQ{*cM-{!=O?%B=U=cC3<aCfQWK%?_dFaByD5ocL8H1+cCLu5ziOZZ5kTY+*5x$VPsk5nV>uc|rT^1Otr3MoBc`Y>kr~I3O5h{h_guw(TS-TutF&)&_5?ZS9V(WdEiTFApg1}LgXJ4}4Q<!SReIglE#91Jn?f4#f(Wu!!vPCv#6dzraVjdc#$6C|=lqIT?00j65bV{a+(*Wzn0IHX~><$T1IU`5Wqy1sN70!7FRzp~tv(QhlpX+`8yFy%LvnVqhwf(BSr&Bf2$DXeiiJlL`=vEeh8|RMRIZrrT<K?e4)Tlj$vk=aCUHCvE++W;AtOpqOMRFWBFjEC<Nk)vW6B(!liBI7#Ptt$Lc8XzW!Si!8yEBxsy9X(3(b9W}dqxGmyVQvmRAXxe&Dbe3{9b&Hphy~!fbDO0a<tomj18sgXh5P1NbK6PKYV^`u9JVs`nA=&4nA0OPmWF?HEK<6#N7hu4I*|`LozI4|8w3}g5-7UKypP%U%$n!AcG%hpH>?XAt*P0>zP4opF`zvrF)=e$wC~nX4<XoTR%fotvD&pEirnbI^C5l2&|F?anUb?1tHAX<wU`dXT_$`isIUNvH{w6wMUn?%<?e4RO{zvH?71q^0_}eci+eA-$6PPdt_G6nQ63Wzaq|lId3<w*JfEMDN?RmW?O^b3Ces{y4;7fLm2a=JGL=0l<=|<jaanL7tF{gBTm|y>#mB>&i!P7$cJrqLs9qZy^`zG8$~zhw5$uYWw&Ho*T~hfjmR%m=vC^DJ|a(J{R*Ia?Z%AQ^T?Ci!~H?)&A<c!nVt>*3nj&qbw=iuPqe{S?@2=c0tL8X&6Wio^v)@YBWY!67$7!uuZB$*!<J-byuN--;@bl2>gCl28Vzp*iZHL4zC*=_8{Pk-2RW)N>>l1O0ZV5wJ%t2JM0zHVB$Jt79mtFRs&3gA!sCm+&f6glafgwJs}+3<I_u@HFdbAmSbWA-DPWAuvD5omv>D`aKS8JBRRw^PKrns)Z0Df#|IHb-vwbz4&6w7!xN~E;I>5)!4h+iRY_B$@Iiqcqj%#_P=U^`?zd|k10zS5YM4lB}Ue4CtZv4NRw@@Vc^1dscp8S4QSlt-z)slIOd;bf)ElWZzKUCvPG)-~n=B5pfO!M_<v;ePf!MG1>jdISbHGi{y$D{lbPXScy$dtB%^5Xk_S0vug;<J3>q35<1NTd}emkFSn0?-Aj<U_s5)%iac07-J$Yu75wna71eBSAMf%XMOiiC9%sP@MnOS>3M#)X!+?L;y>&<U@*TB8B6hFcrvP#GdAb?(K92ITOX5=!hbrI5G8<!mB?T2M_3_T6IzJvo<WZ<al~OI%hq{-Gd1i{#?e6vsV-iZmQRzI$Qk)>eCZsk7`I-0?LHw3ZzGf2b8_ud0E?jAgRfTYD2S8-sJ^JDUET0&=N*k`F_aAjR*OsPJZQKYQ9@WK3_00D%B8oOq1E7_(RtTNs%iPIcyzwVem*3v@Uv;_3t5Fgf=3W^glPx&28crkS%`ChYWA*_eg9S7d+4KlSPTj_+3}dMrT1iK-q>e-@y<)T{FbDPOv@U(k$Eu7HvHRJNG~9O&SFg3){nx62sjBp{Dh*u<UAv;%9-ecUfx%U+D<mRR7+ZzHo7X_Jp8tBw4?VNViu$B0(GpqE^9o4ES`XDRV2!m_xp}3QN>B)OoG`>`8On;I=$_U_wXZ(Z3tt^EGKG^0lU=UskgLwz!5qbn8v3kCS^R`ut1H(zJ=#3wiLaOscFNN=obZ-wlY@X)Rd^oUhJgZN4SU$a08#-LUNk1cjdvg^Pb8OjBF3bL2-O*cWKh3?@~v-z`7KMKLVsBAU*QM5%k!zbj?V7*?}no(3lqg%cmr<=7~c0sXHD-I$#A)H9-b6UZ#`kZHCu!L?nzWOR9dJ1M!x<2$Fit=I5HRTAX<DdHvgtVfYlH{J%xAF|Be{HMjXN#B9OS5@5gZ!L;Ozz3raEROrc8Zl-is+3*t!KU7@X$eXb9AUMV49T~mxkyG*7-<8j$L{dA{k6v+>i)o9VZSL*sb_0tjN%|bO%xJEwE2Qi9~`seH)+RsW}f1vx>ft|o?T{U8j3)2r$Ezunxk5wrN~GxSuo#_<5vEBr8dJXVppnzpxZ&mC5n_PrvVB05BkVW*-a(W2tSNWR;h5A#y+I7zya1i3Guu9+((n9wh>FF03+#u;jQW56qY@Q$Mb>vpKO_%T<9}eLizqWb25OeOnn{IwUcQmk*`J~)p`!*r9|_T9RY~Ej-v6<YwJ@>A0N}q1|BOPg)S_|SL3Ex|3R-U>12{s<SR?ylyPn@Zz$2aKZyU%B4wt1fMj_xLmR_TI@1LvyQ$D74<hu5@Hq2kU-0tygS22&>|Yd<ekDI6$FN`XO57I*(u+IQM|}s<l7EgcbTXOq>HX;SUuzYuU7IYq5umlGWbk5A;AhL2fRhc%eWDV_!h(3%Eib4scAa5P>83)wP8!VdkBDYqH}nSzDt(8y9HeQ5&&6|ug&dgFuBlWD00y8ZYh8$WV&xk@P{ylav0kmcnKJRk&>q_JSL1r!g^i|&fM0}l8ZI%-JNc8X%TC}VXNPk#Vc)?e&mi~z1Y-e3IOHTRK^ZvCxyx$j?(TR!U&0FOHC#?FKoEfu;%N0~h!9{IL0Hhi3o5c=>?LK1vySoiPQCwclDKB+BZObU;haJRJN$r3knr`E<O@|oIH`Z3pTEK%>VVGzS{a6&mezlw=ZUIxaeJAP)IZAqysDK@c;)lp`WR)K)+Q%Qi5Vh)s;UZ#<(aKM+)Ml}>-(*=U^ly_ZWm&#gGgT6Xb1cWX~F&tZ`(+S0m!MXiWJ@%?iG||t3NqE1C-4&q=%G>;>~{#Ci7w}<<~K#jQdSgxJ+oOH{qhx)=+lngNQJ;yiw%X{n*!43FVteGRb|`ED$soL^g}Mo=63P+%hHh2LmJLvH*`<?)-mH){r81y#EDV7vrs(bhb}U$Y4~_H<l7HxFMQ{Yb=IG6Ms;-TpV5UY%KAAIudZ}hVZUN7P8xC{!6j2fLA*(g<b#v&ls}j)-XhF00EmT$cX^}@B8CMvBYQl0ssI200dcD',
    'scripts/test_build_results_portal.py': '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;0oCT-dz9@h(bq-BQwKy4>SE$m+hy=@aif<Hp(x8Bq4Be2z3vOSbYX;2L?oxBd+qlq6t(}=={*qOa%XhhuNp7MGD|7FwPu@z3nFUfW&+*s9jd$<eTytdIZtispn~29lyu|7B3N0MW_k3etd;SdzSugU-8ki1i+mW>{sYNvAxU&J!yz|;k|df1<@yr&jIpef)xR3-=m1H$gO(omT8=WQo4kylcHge)4u1~D{5;)OW5_rBC-ZueqK2mc*5eoYZ}}1KJQP3ls9-P)b#4?nDH2x-kt38bBT#^X9=k~Vtalc#+6f|iHI%{f@0y98kb(NiM_axU~~taX>JvGpJd{n)*9Ej!V#My3a+%@|A7CIbhTg`Xe9;fcg;J6BYMF6l)*2AVk)a=YuTGcINQS(`ih;>EaHPHA_z>*(E;a9zOOV~cYt7-bXhZcFYQ?l@Kr7DOKQMf)H?J(Glc13Zg*fa^{IoM>d*?lo|Mf7HYbSJ0WYSgmdjr;`R!bmtoT?&71w29j(&fjg(zlsI!7+=NxGSlrm;E!z61Z67^TMv!5I4iXFL|l-P=<T<hI67v)Zt5<3-|kSs@Vxu&!tOfaEoLdupYy6;v?mx7Uec33Kp9l*5wk2IO8p%qG~L1JKmtY5roAK3OJ)dii%r>^5lV_uQ-UC+0*>#`K?*LO+^u0<<|$Ii>R9b-PyuJ3{q(QNVj&#C6!aG@gb(9OdKJ57dz+)G2g)tuK+(9WxOf7Q=|?*^1&y-^+~r_#{X~rJisS)igZraRub2A3P<oVgdBrdNXLrN;<<So5AAk3+A?{0=EmIC>9=P@}JqW7z>+s;<rk=&5mNrsxedZ&mX;s1E5s8ppl<a07@PrwPuyo`A6Z30(ns5<O<)CtN;i!=PaSrM~?W>W2Z3GqW}!*0Y<B)1mgv3Of7nS`KL`fZ2`M5e{lK@;a;MVF{f4y$8G}zACqio7ALUq2T{;$Ci27DB}%{1u_+bBR)B+&BHARhG`Oo#nu=WemtoH@Y-2grn?_fo(!F<yDUZ^f8R)1Mh<jQnfl>|bZ&p6zDc`9I3@)qUUKICF7n~>`CSFEwD7y*a8M*RpSw*PgWVqM0Q#d6>)uxLnUy?CN-=(#TOIpe?KZSR-1Z;K4>jiWaHYKf1Vm&x<-eIYG*TeT2#<+|>q|sEjKFq_N5ebp|j;Yt@Yo8K7AG6B?iWNLh(B~7pC^1T@`|+O0jIolbMafx!aP`sNjp|7H0Z^xlBQ0dJIxpwBG1|>3l1PfB=Zo448l*Z;%>V!ZTSVMSsniPo00H_3+7$o*)Czc(vBYQl0ssI200dcD',
    'assets/site-refresh.css': '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;360Zzg++qihv}m&!${ps$X?SbT2*Y)0Y+_{_Uu8c}bhH^iyn~EV6FR8r68dfOJdz(wEa=usZrms7wHRCBE`%Usj;@{Xyu6-leZ9s#4qqNWR|oz#!66uLhyYH&p)2uLHjT@X4{AD`Jn96a}h15~vtuW0y<rJf_XDXdAt33&0jl@e@9SsOLPi<_K%?v`D6%`;GZm`5m_9Xi<9Q3Ex8KsF7in5E{O}3EkOEdS6LmbPv4k0s4myUnYD;IoXM;-D9y1#fWqpKZ<r2jjSykp{5(0ieFD#BAj`Gm1*Xx7WR=~Ft0^{#Mo6d=C`wljJ3=b2Im{mkir3yJjsOgKTis3B3LISTd>hQ4^So32-h{UpxgIoSbOMV;4cn4NqEw)bz{hz<pF1}=?CFuUBIVfV|$lI@PRV^8ltx2IfoF3FnSBS1;ElW9wSWtB(DJGY}G&Sg#LadmG%$^+Ac~e`a$ZfwVHfm;g2PDif`i7pA=lMlRQ)weqAD|b`xNsn(Hbs5TlUgi4NzMQzDfF<JIaZcQI{8ZnR4PR9z@}(p{uf*D3ycKegi>!HL`(i+`4znq7rkr}IyyDOQ}#EuWQLJ`teSN|W-OAbAz)9Xw)|6moy;{9{3q{IK0N?b2jr+pSm7a|s6`H$S7tJyPfVyhwdV_UOQA{+<E_W1M@%odMQHEk5z<oZ9-MjwKy&z<eFVh&Ix#C8j-(xRI!t(Qrr9xtc`Vxc*)4u5QI}AZ2-PNsQ)6?_dB4$$2&Dt`6*8w=X)TPJtSdR9qkW0Ky?wkKuahn)GF_{?~NihK;kd-9?fXDb<_*;XbfkExv7oC?GZHJ*wr-mwo%HxC7MDhPJl@6^J~NC{>?w>tNKZ91QI8x|_Kz4i-CQp~GFYHi$nCLUx|4lKmIjoDt1=w8Aerf?#ZWR{4pAPWV7;enlL-`LYz;xtQu+e}G(Iuzu$6oe?YA$@~mtqIy9$UK+`IP7AK`d*BLk^}keyX^%is_OGE&$ylwT2)u9pfS5G3O<~a;n``?XJ%AGCiwsgK%}z^AFQgjlQ;UdclOsQtT85n%hynUXe%Dy?j6X7_`Y)~)QBUT$9rH9WqELz|>7X!a4TiRO#w@8^o=(d`_tF<ZkBQi7Su4t0o^8%nV|t7|i#=8@0MbSG53EME>6hq=3;IR?$M%Lea<l71yQ@x7$f>c6RTZ%uWyS4HPaG<d^VObHl;B|;;e0+F;j?LIg*#yB-H*DTKFPm-6lIeX+rU1dnP`Julvwo!d&j;i1AcPIs(W)R$=X1|bh;lX&+E=47ETv0&NCAx-}5p}R2O{((P@(D<|>h4xbVWVO5SwYdCx-`abxRLo0aUsGh17YG%b|XYXM6G!5q{q2sbvB5Oh+hs2sji;`1X)1TX?C(%CWQMRF%+stWC~kBrw^*9Ej-F1nhz3E()*+^M{8|FmLGdlKRnuRi?z4+g<-iJ&FShp&48S?xF2M9X#f#uE0mb~l=rILw8!>hIg-XDle?hf?Q+EeA>9k;*S_PlHoS^(slHmlT%O4}#0&McnF%3YbRYlStv0`pjx2@lDzwtyTR{N$o{~$@Dr#Zsrk&U$N`@@*nIY$pk3@r^@0jx?SRDW)+b$mDh%*AfFA!lNt_tzXkfuzfqk+80M&-&-2fjyM<Di?)ssI!_6%~C=UlaMLY=@nanrWJXQc$osffV)5Nx;m2-)+=HiSW=4~)T5akJgToqbqx&uHwFX`Bc#f5X_1k~xL#u3y9rn;i63A?$HQloiWKZ`MWRD+!E<silk)CJi0qM(N*?p{BudYU<)m24(To(=!dAvteDZfK&wmtL@?E?_u4MtkNwN-}K6A+E66J<7vtS3C{prf^W9>^@JOm{fkM_1fw>LCNXUFt|d5zN!E<SGyga5FGiXO`c;{F!0-K#;?d?>l`WaB8g3zOHwsf|JnHQs>Ez@2~he*mNvhm9Cvi#d$Dg@1iuxne`!~6&n|#Rf#Ok0Zn0u@9$2zt6i8C_cfsBq@i4?z=K4f8Tvf<uaq$zutu#ruMh?Pg?^sLWpW+96l8w8e>>&<v6E2^t*mWX*DF{go)8Eme(Xn-taaV;cKgD~VADt~TQ!+QkgIzYBbg?fTYktLxtWq7sUwAAQVcpBkQii9NvP@gV`3Q<r78WTGzZ{$$0^_1V)Yi%c(#-XV)vP`h{kiXH>SFODNU%K?n+N)1s+SxYP1n|0Sr^_26zU}`N3~Fd3L|zhZdGB_K}w=JIa!tkvzL)il3(td<P_HOpn)n0koBdOa7_zFHz3;DB*BMpL&Mh7pWs;|a(Led$G5I!33)&XGt3)*=XWEZgopA&;rnYf=TO8Pe|gY<mbdZ7uq*HmQghl^NCmM>DtmEo?@9XM<=3!7auN7_*Iv%aOmpMP6{h31T)fEsB}<ddrX@2BBd`PiD__EUs1HlNpN_5A)*_Ldo-*jFe3i(RVVJ7)AT4IFH>lmkXhA5xYE;oTPxO^EeXW0Blh;Hl&fjyqL0y5>fm^34Nm_Rtp?g~KG6wpN1kgwdSMD%wnwk`-<L0JEK8bP#&XiFDCoD|7#5m5)WWcre_E;*R@=vg+?D>9c?}rpJ<MH~3O?@(nj3ov}aww+?Y#5R^3;hkzr0KNP!%@bg*#y7@R8wKOCLgqrQh};N<b+kBLTOk$mV#~nMSON{0HBI@mU+Bl%-K(%DrFF0dA9li^$~#g#NhdGLuMTD{Jf!X30tsY>o2U;MT`6BdI$<x$38&Zz#;bTsQFdZc`7$&i(wX*&4thIU#D!wVB)ubOohZeEa}w@1L5;7q?mi_T{JkVi=lAXx)y-bf5^)2_n(&}aY}lmgB1iw1qyC_3@3)-cMSQj&d87_0MF@6G-F7*PaWZslfGe4f4Beusk3WWCM!W$00G+(nM42pF%9=ovBYQl0ssI200dcD',
    '.github/workflows/public-results.yml': '{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;0OBxLtOwj7)ky5`&L@rla7ygIz$jXjU4^Fea3C$_k4q6R<eZX`hNtOLZ&y_ey1lsD4&0lGUpfx(6j8A8rhsYai^<tS+va#exS$Bw8M>bXC!_m394n#9#$*AAM&&|qBtRh$B<!QxG>#aT1QGUgyH=x#D92_upZ+eiS@y9ETpCr_yw4gR`Z|_P0)TY5uzB~Je}BsKe%Zv#kAM+B#a-|s;=mJz{7ZwhuiPP3sG6IxVU%k{wR|k0RxTI&gw|qs*k14Zzp8}y=DUDWZ8th&~m~a#ZRS@(k?p2;K?wsJ@vrK({fr0tj*#<HL;8}2|R!TRiV-+9d!Z}grZ$C2f1n7RsqRlx(ZhuFHRyI+4sv$0K?v<{FvKp(0{erSF2ypfoJ793KKoM;K<`;AGturxY+Bi^Y7<vXfQB;B3NQ6dkX(3MtXeB?i8w17Am7IT_X2MQAglL!&zD1)bCKm<8~MJ7DlcA9r;L~E~JsM*xGd8xJaUn7+Wp^@EWiFh%abD_ylgRKb>nwkO$w&7t7vmp0v}cLi760+-#vKHa3<KGi_-yC(^#HM!Lr3;77v4up)t8qRJ3m7zO|)|F$#ai|Un;TuA~SS-E&UtQdC?@!KOAWx%&$UX#!gew!U21PDhfqA5cmh<4f6hn*fXP9j|l)863FvzQ>3+`VIQ9OwXmS``owZ*Md2E_ytEl*F%dJvwa3pooKxOTuzM#tp0vHFbl=6mA8S6O+J87-0zs6UncM*}wn*uj(F9gW%U<00G|w{0{&C#WGP6vBYQl0ssI200dcD',
}


def decode(value: str) -> str:
    return lzma.decompress(base64.b85decode(value.encode("ascii"))).decode("utf-8")


def write_payloads() -> None:
    for rel, value in PAYLOADS.items():
        path = ROOT / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(decode(value), encoding="utf-8", newline="\n")


def insert_in_section(text: str, section: str, anchor: str, addition: str) -> str:
    start = text.index(section)
    point = text.index(anchor, start) + len(anchor)
    if addition.strip() in text[start:point + 3000]:
        return text
    return text[:point] + addition + text[point:]


def patch_manifest() -> None:
    path = ROOT / "repo" / "ARTIFACTS.yaml"
    text = path.read_text(encoding="utf-8")
    text = insert_in_section(
        text, "  generated_views:\n", "      - STATUS.md\n", "      - VERIFIED_ALL.md\n"
    )
    text = insert_in_section(
        text,
        "  generated_views:\n",
        "      - dashboard.html\n",
        "      - results.html\n      - sitemap.xml\n      - robots.txt\n",
    )
    text = insert_in_section(
        text,
        "  generated_views:\n",
        "      - scripts/site_generator.py\n",
        "      - scripts/build_results_portal.py\n",
    )
    text = insert_in_section(
        text,
        "  generated_views:\n",
        "      - scripts/check_repo_artifacts.py\n",
        "      - scripts/build_results_portal.py --check\n",
    )
    text = insert_in_section(
        text,
        "  public_site:\n",
        "      - dashboard.html\n",
        "      - results.html\n      - sitemap.xml\n      - robots.txt\n",
    )
    text = insert_in_section(
        text,
        "  research_os_control_plane:\n",
        "      - repo/ARTIFACTS.yaml\n",
        "      - repo/README.md\n",
    )
    text = insert_in_section(
        text,
        "allowed_overlap_paths:\n",
        "  - dashboard.html\n",
        "  - results.html\n  - sitemap.xml\n  - robots.txt\n",
    )
    path.write_text(text, encoding="utf-8", newline="\n")


SITE_ENHANCEMENT = r'''
  /* KEYAI_RESULTS_PORTAL_V1 */
  (function setupResultsPortal() {
    var refreshPage = document.body.getAttribute("data-page");
    var repository = "https://github.com/KeyAIGit/-ecdlp-lean-verification";
    if (!document.querySelector('link[href*="site-refresh.css"]')) {
      var stylesheet = document.createElement("link");
      stylesheet.rel = "stylesheet";
      stylesheet.href = "assets/site-refresh.css?v=20260816-1";
      document.head.appendChild(stylesheet);
    }

    var nav = document.querySelector(".primary-nav");
    if (nav && !nav.querySelector('[data-nav-page="results"]')) {
      var resultLink = document.createElement("a");
      resultLink.setAttribute("data-nav-page", "results");
      resultLink.href = "results.html";
      resultLink.textContent = "Results";
      var routeLink = nav.querySelector('[data-nav-page="routes"]');
      nav.insertBefore(resultLink, routeLink || null);
    }
    var footer = document.querySelector(".footer-links");
    if (footer && !footer.querySelector('a[href="results.html"]')) {
      var footerLink = document.createElement("a");
      footerLink.href = "results.html";
      footerLink.textContent = "Verified results";
      footer.insertBefore(footerLink, footer.firstElementChild);
    }

    function guideLink(href, label, description) {
      var link = document.createElement("a");
      link.href = href;
      var name = document.createElement("span");
      name.textContent = label;
      var detail = document.createElement("strong");
      detail.textContent = description;
      link.appendChild(name);
      link.appendChild(detail);
      return link;
    }

    function setupWorkspaceGuide() {
      if (refreshPage !== "workspace" || document.querySelector(".workspace-guide")) return;
      var tabbar = document.querySelector(".tabbar-wrap");
      if (!tabbar || !tabbar.parentNode) return;
      var section = document.createElement("section");
      section.className = "workspace-guide";
      section.setAttribute("aria-label", "Workspace orientation");
      var grid = document.createElement("div");
      grid.className = "shell workspace-guide__grid";
      grid.appendChild(guideLink("results.html", "Verified results", "Find the checked theorem surface"));
      grid.appendChild(guideLink("explore.html", "Route decisions", "See what is selected, parked, or closed"));
      grid.appendChild(guideLink(repository + "/blob/main/STATUS.md", "Canonical snapshot", "Use one source for live numbers"));
      grid.appendChild(guideLink(repository + "/blob/main/REPOSITORY_ARCHITECTURE.md", "Repository map", "Understand ownership and edit policy"));
      section.appendChild(grid);
      tabbar.parentNode.insertBefore(section, tabbar);
    }

    function setupHomeResultsRibbon() {
      if (refreshPage !== "product" || document.querySelector(".results-ribbon")) return;
      var target = document.getElementById("product");
      if (!target || !target.parentNode) return;
      var section = document.createElement("section");
      section.className = "results-ribbon";
      section.innerHTML = '<div class="shell results-ribbon__inner"><div><p class="eyebrow">Verified results</p><h2>Two ledgers, one clear entry point.</h2><p>Browse ECDLP and ResearchOS results together without merging their canonical schemas or counters.</p></div><div class="results-ribbon__facts"><span>Current counts load from the canonical registries</span></div><a class="button" href="results.html">Browse verified results</a></div>';
      target.parentNode.insertBefore(section, target);
      if (!("fetch" in window)) return;
      Promise.all([
        fetch("data/stats.json", { cache: "no-store" }).then(function (r) { return r.json(); }),
        fetch("data/researchos_result_registry.json", { cache: "no-store" }).then(function (r) { return r.json(); })
      ]).then(function (values) {
        var a = Number(values[0].ledger_rows);
        var b = Number(values[1].ledger_rows);
        if (!Number.isFinite(a) || !Number.isFinite(b)) return;
        section.querySelector(".results-ribbon__facts").innerHTML =
          "<span><strong>" + (a + b) + "</strong> cross-ledger entries</span>" +
          "<span><strong>" + a + "</strong> ECDLP rows</span>" +
          "<span><strong>" + b + "</strong> ResearchOS rows</span>";
      }).catch(function () {});
    }

    setupWorkspaceGuide();
    setupHomeResultsRibbon();
  })();
'''


def patch_site_js() -> None:
    path = ROOT / "assets" / "site.js"
    text = path.read_text(encoding="utf-8")
    if "KEYAI_RESULTS_PORTAL_V1" not in text:
        marker = '  "use strict";\n'
        text = text.replace(marker, marker + SITE_ENHANCEMENT, 1)
    path.write_text(text, encoding="utf-8", newline="\n")


def patch_fixpoint() -> None:
    path = ROOT / "scripts" / "check_generated_fixpoint.py"
    text = path.read_text(encoding="utf-8")
    if '    "VERIFIED_ALL.md",\n' not in text:
        text = text.replace('    "STATUS.md",\n', '    "STATUS.md",\n    "VERIFIED_ALL.md",\n', 1)
    old = 'SITE_ARTIFACTS = ["dashboard.html", "index.html", "explore.html", "pilot.html"]'
    new = '''SITE_ARTIFACTS = [
    "dashboard.html",
    "index.html",
    "results.html",
    "sitemap.xml",
    "robots.txt",
    "explore.html",
    "pilot.html",
]'''
    if old in text:
        text = text.replace(old, new, 1)
    path.write_text(text, encoding="utf-8", newline="\n")


def main() -> int:
    write_payloads()
    patch_manifest()
    patch_site_js()
    patch_fixpoint()
    subprocess.run([sys.executable, "scripts/build_results_portal.py"], cwd=ROOT, check=True)
    for rel in (
        "scripts/materialize_site_refresh.py",
        "scripts/materialize_site_refresh.py.xz",
        "scripts/run_materialize_site_refresh.py",
        ".github/workflows/materialize-site-refresh.yml",
    ):
        path = ROOT / rel
        if path.exists():
            path.unlink()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
